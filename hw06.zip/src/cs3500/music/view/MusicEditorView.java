package cs3500.music.view;

/**
 * Created by josh_jpeg on 6/14/17.
 */
public interface MusicEditorView {
  void initialize();
}
